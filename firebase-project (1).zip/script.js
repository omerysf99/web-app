import { initializeApp } from "https://www.gstatic.com/firebasejs/10.0.0/firebase-app.js";
import { getFirestore, addDoc, collection, getDocs, query, orderBy } from "https://www.gstatic.com/firebasejs/10.0.0/firebase-firestore.js";

// Kendi firebaseConfig bilgilerini buraya yapıştır
const firebaseConfig = {
  apiKey: "BURAYA_API_KEY",
  authDomain: "BURAYA_AUTH_DOMAIN",
  projectId: "BURAYA_PROJECT_ID",
  // storageBucket, messagingSenderId, appId isteğe bağlı
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const nameInput = document.getElementById('name');
const coinInput = document.getElementById('coin');
const addBtn = document.getElementById('add');
const loadBtn = document.getElementById('load');
const playersDiv = document.getElementById('players');
const statusDiv = document.getElementById('status');

addBtn.onclick = async () => {
  const name = nameInput.value.trim() || 'İsimsiz';
  const coin = parseInt(coinInput.value) || 0;
  statusDiv.textContent = 'Veri ekleniyor...';
  try {
    await addDoc(collection(db, "players"), { name, coin, joinedAt: new Date() });
    statusDiv.textContent = 'Veri eklendi ✅';
    nameInput.value = '';
  } catch (e) {
    console.error(e);
    statusDiv.textContent = 'Hata: Veri eklenemedi. Konsolu kontrol et.';
  }
};

loadBtn.onclick = async () => {
  statusDiv.textContent = 'Oyuncular çekiliyor...';
  playersDiv.innerHTML = '';
  try {
    const q = query(collection(db, "players"), orderBy('joinedAt', 'desc'));
    const snap = await getDocs(q);
    if (snap.empty) {
      playersDiv.innerHTML = '<p>Henüz oyuncu yok.</p>';
    } else {
      snap.forEach(doc => {
        const data = doc.data();
        const el = document.createElement('div');
        el.className = 'player';
        const joined = data.joinedAt && data.joinedAt.toDate ? data.joinedAt.toDate().toLocaleString() : '';
        el.textContent = `👤 ${data.name} — 💰 ${data.coin} ${joined ? '— katıldı: ' + joined : ''}`;
        playersDiv.appendChild(el);
      });
    }
    statusDiv.textContent = 'Tamam ✅';
  } catch (e) {
    console.error(e);
    statusDiv.textContent = 'Hata: Oyuncular çekilemedi. Konsolu kontrol et.';
  }
};