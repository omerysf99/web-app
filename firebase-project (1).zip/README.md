# Firebase Oyuncu Paneli (Örnek)
Bu proje, Firestore'a oyuncu bilgisi (isim + coin) eklemeye ve eklenen oyuncuları listelemeye yarar.

## Kullanım
1. Firebase Console -> Proje oluştur -> Web uygulaması ekle.
2. `script.js` dosyasındaki `firebaseConfig` objesini kendi proje bilgilerinle doldur.
3. Firestore'u aç ve 'players' koleksiyonuna izin ver (test modunda hızlıca çalışır, sonra güvenliği ayarla).
   - Konsolda Firestore -> Create database -> Start in test mode (geliştirme için)
4. Dosyaları GitHub'a yükle veya yerelde aç:
   - GitHub Pages ile yayınlamak istersen `index.html`'i root'a koyup Pages'i aktif et.
5. Siteyi aç -> İsim ve Coin gir -> "Coin Ekle" -> "Oyuncuları Göster" ile kontrol et.

## Notlar
- Bu örnek eğitim amaçlıdır. Test modunda Firestore herkes tarafından yazılabilir olur; gerçek projede güvenlik kuralları koy.
- Firebase API anahtarları gizli değil (client-side) ancak güvenlik kuralları ve kimlik doğrulama eklemek önemlidir.
